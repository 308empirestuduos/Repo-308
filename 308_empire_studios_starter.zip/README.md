# 308 Empire Studios — Flutter Starter

A cross-platform starter for an advanced mobile video editor.

## What is implemented in this starter
- Flutter dark/royal UI using midnight, gold, silver and white.
- Import a video using the system file picker.
- Preview the selected video using `video_player`.
- Add imported clips to a basic in-memory timeline.
- Split a selected clip at the playhead (timeline model operation).
- Set a trim-in and trim-out range in the project model.
- Add an audio file to an audio-track model using the file picker.
- Save/load a project JSON file locally using the share/save flow is a future task.

## Important limitations
This is a starter code artifact, not a production-ready editor:
- Timeline edits currently update project metadata; they do not yet rewrite media files.
- Trim and split operations are represented in the timeline model.
- Audio is imported into the project model but is not yet mixed into video playback/export.
- There is no rendered export yet.
- The native Media3 Transformer and AVFoundation export bridges are specified in `docs/TECHNICAL_BLUEPRINT.md`, but are not implemented in this starter.
- No project persistence, undo/redo, waveform extraction, proxy media, or background rendering yet.

## Run
1. Install Flutter stable and Android Studio / Xcode.
2. Create a Flutter project, or use this folder as the project root.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android or iOS device.

iOS builds require macOS and Xcode. Android builds require Android SDK tooling.

## Dependencies
See `pubspec.yaml`. For production, pin and test dependency versions against the selected Flutter stable release.
