# Next implementation step

Implement the native export bridge in two stages:

1. Define and version the Flutter `MediaRenderService` contract and JSON schema.
2. Implement Android first with Kotlin + Media3 Transformer, then iOS with Swift + AVFoundation.

Acceptance criteria for the first native-export milestone:
- A project containing one imported video exports to a new MP4 file.
- Export can be started, progress observed, and cancelled.
- Original media remains unchanged.
- Output plays in the device gallery/player.
- Unsupported codecs and insufficient storage return actionable errors.

After one-clip export is stable, implement composition of two clips with trim ranges, then add an audio track and mix it into the output. Do not advertise full multi-track export until it passes device tests on both platforms.
