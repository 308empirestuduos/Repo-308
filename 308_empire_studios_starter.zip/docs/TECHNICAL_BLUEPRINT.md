# 308 Empire Studios — Technical Blueprint

## Product target
A professional, non-linear mobile video editor for Android and iOS. The design system uses midnight black, gold, silver and white. The product should support a multi-track timeline, frame-accurate editing, audio mixing, titles, transitions, colour tools and rendered export.

## Architecture

### Flutter layer
- Application shell, navigation, project browser and editor UI.
- Timeline model: projects, tracks, clips, source ranges, timeline positions, transforms, effects and audio gain.
- Editing commands and undo/redo history.
- Platform abstraction through a `MediaRenderService` interface.
- File import and project persistence.

### Android
- Kotlin platform implementation.
- Media3 Transformer for composition/export where supported by the selected Media3 release.
- Media3 ExoPlayer for playback where suitable.
- Validate codecs, effects, HDR behaviour, rotation metadata and device-specific hardware encoder limits.
- Use a MethodChannel or Pigeon-generated typed interface for Flutter/native communication.

### iOS
- Swift platform implementation.
- AVFoundation `AVMutableComposition` for video/audio tracks.
- `AVMutableVideoComposition` for transforms, frame timing and supported effects.
- `AVAssetExportSession` or a custom AVAssetReader/AVAssetWriter pipeline for export.
- AVPlayer for preview.
- Validate supported codecs, HDR, orientation and export presets.

## Core project model
A project has:
- `id`, `name`, `width`, `height`, `frameRate`, `audioSampleRate`.
- ordered tracks.
- each track has a kind (`video`, `audio`, `overlay`) and ordered clips.
- each clip has a media asset reference, source in/out, timeline start, speed, volume, transform, opacity and effect list.
- all edit times should use integer microseconds or rational frame/time values internally. Avoid floating-point seconds for frame-accurate operations.

## Editing operations
1. Import: probe media metadata, copy or reference the asset, generate thumbnail and waveform jobs.
2. Place: add clip to a track at a timeline position.
3. Trim: adjust source in/out while preserving timeline start or ripple behaviour according to selected mode.
4. Split: split a clip at timeline playhead; calculate source split position with playback speed accounted for.
5. Move: reposition clips; support snapping and collision policies.
6. Audio: add audio asset, gain, fades and later ducking/keyframes.
7. Preview: render current composition; use low-resolution/proxy previews when required.
8. Export: translate the project graph to a platform render composition, validate output settings, render, report progress, handle cancellation and clean temporary files.

## Platform bridge contract (proposed)
Flutter -> native:
- `probeMedia(path)` -> duration, dimensions, frame rate, rotation, audio/video stream metadata.
- `createPreview(projectJson)` -> preview session identifier or preview source.
- `exportProject(projectJson, outputPath, settings)` -> job identifier.
- `observeExport(jobId)` -> progress/state events.
- `cancelExport(jobId)` -> cancellation acknowledgement.

Use typed request/response models and version the bridge contract. Do not pass arbitrary executable instructions or trust paths without validation.

## Export settings
- Container: MP4 initially.
- Video: H.264 baseline/main/high as device permits; HEVC optional later.
- Audio: AAC.
- Resolutions: 720p, 1080p, 2K and 4K only when source, device and encoder support them.
- Frame rates: 24, 25, 30, 50, 60 where supported.
- Bitrate should be configurable or selected from quality presets.
- Always report actual export dimensions, codec, duration and errors.

## Delivery milestones
### M1 — Import and preview
- File picker import, metadata probe, playback and basic project model.
- Status: starter code includes video file picking and preview using `video_player`; metadata is read from the player controller.

### M2 — Timeline operations
- Multiple clips, track placement, source in/out, split, move, snapping, undo/redo.
- Status: starter has a minimal in-memory timeline and basic metadata split/trim examples; not frame-accurate production editing.

### M3 — Audio composition
- Audio import, waveform, gain, fades, mixing and sync.
- Status: audio file selection and track metadata only; no audio mixing.

### M4 — Native render engines
- Android Media3 Transformer composition/export.
- iOS AVFoundation composition/export.
- Status: not implemented in this starter.

### M5 — Professional editor
- Titles, transitions, keyframes, colour pipeline, proxies, background jobs, project persistence, recovery and accessibility.

## Engineering safeguards
- Never overwrite source media.
- Write exports to a new destination and use temporary files for interrupted jobs.
- Validate available storage before rendering.
- Keep UI responsive; rendering must not block the Flutter UI isolate.
- Persist project state and recover interrupted sessions.
- Surface codec/device limitations clearly.
- Test with portrait/landscape, variable frame rate, rotation metadata, long-GOP media, large files, silent clips, multiple audio streams and low-storage conditions.
