import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

const Color gold = Color(0xFFD5AC53);
const Color midnight = Color(0xFF101114);
const Color panel = Color(0xFF1C1E23);
const Color silver = Color(0xFFB8BBC2);

void main() => runApp(const EmpireStudiosApp());

class EmpireStudiosApp extends StatelessWidget {
  const EmpireStudiosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '308 Empire Studios',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: midnight,
        colorScheme: const ColorScheme.dark(
          primary: gold,
          secondary: silver,
          surface: panel,
        ),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      home: const EditorHome(),
    );
  }
}

enum TrackKind { video, audio, overlay }

class TimelineClip {
  TimelineClip({
    required this.id,
    required this.path,
    required this.name,
    required this.durationMs,
    this.sourceInMs = 0,
    int? sourceOutMs,
  }) : sourceOutMs = sourceOutMs ?? durationMs;

  final String id;
  final String path;
  final String name;
  final int durationMs;
  int sourceInMs;
  int sourceOutMs;

  int get visibleDurationMs => (sourceOutMs - sourceInMs).clamp(0, durationMs);

  Map<String, dynamic> toJson() => {
        'id': id,
        'path': path,
        'name': name,
        'durationMs': durationMs,
        'sourceInMs': sourceInMs,
        'sourceOutMs': sourceOutMs,
      };
}

class TimelineTrack {
  TimelineTrack({required this.name, required this.kind});
  final String name;
  final TrackKind kind;
  final List<TimelineClip> clips = [];
}

class EditorHome extends StatefulWidget {
  const EditorHome({super.key});

  @override
  State<EditorHome> createState() => _EditorHomeState();
}

class _EditorHomeState extends State<EditorHome> {
  final List<TimelineTrack> tracks = [
    TimelineTrack(name: 'VIDEO 1', kind: TrackKind.video),
    TimelineTrack(name: 'OVERLAY', kind: TrackKind.overlay),
    TimelineTrack(name: 'AUDIO 1', kind: TrackKind.audio),
  ];

  VideoPlayerController? _preview;
  String projectName = 'My First Production';
  String activeTool = 'Select';
  int? selectedClipIndex;
  int playheadMs = 0;
  bool isImporting = false;

  TimelineTrack get videoTrack => tracks.firstWhere((t) => t.kind == TrackKind.video);
  TimelineTrack get audioTrack => tracks.firstWhere((t) => t.kind == TrackKind.audio);

  Future<void> importVideo() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.video,
      allowMultiple: false,
      withData: false,
    );
    if (result == null || result.files.single.path == null) return;

    final file = File(result.files.single.path!);
    setState(() => isImporting = true);
    try {
      final controller = VideoPlayerController.file(file);
      await controller.initialize();
      final duration = controller.value.duration.inMilliseconds;
      final clip = TimelineClip(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        path: file.path,
        name: result.files.single.name,
        durationMs: duration,
      );
      await _preview?.dispose();
      setState(() {
        _preview = controller;
        videoTrack.clips.add(clip);
        selectedClipIndex = videoTrack.clips.length - 1;
        playheadMs = 0;
        isImporting = false;
      });
    } catch (e) {
      setState(() => isImporting = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open video: $e')),
        );
      }
    }
  }

  Future<void> importAudio() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.audio,
      allowMultiple: false,
    );
    if (result == null || result.files.single.path == null) return;
    final file = result.files.single;
    setState(() {
      audioTrack.clips.add(TimelineClip(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        path: file.path!,
        name: file.name,
        durationMs: 0, // Audio duration probing will be added with the audio engine.
      ));
    });
  }

  void splitSelectedClip() {
    final index = selectedClipIndex;
    if (index == null || index >= videoTrack.clips.length) {
      _message('Import and select a video clip first.');
      return;
    }
    final clip = videoTrack.clips[index];
    final splitAt = playheadMs.clamp(clip.sourceInMs + 1, clip.sourceOutMs - 1);
    if (clip.visibleDurationMs < 2 || splitAt <= clip.sourceInMs || splitAt >= clip.sourceOutMs) {
      _message('Move the playhead inside the selected clip before splitting.');
      return;
    }
    final originalOut = clip.sourceOutMs;
    final right = TimelineClip(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      path: clip.path,
      name: '${clip.name} (split)',
      durationMs: clip.durationMs,
      sourceInMs: splitAt,
      sourceOutMs: originalOut,
    );
    setState(() {
      clip.sourceOutMs = splitAt;
      videoTrack.clips.insert(index + 1, right);
      selectedClipIndex = index + 1;
    });
    _message('Clip split in the project timeline. Media has not been rendered.');
  }

  void trimSelectedClip(double value) {
    final index = selectedClipIndex;
    if (index == null || index >= videoTrack.clips.length) return;
    final clip = videoTrack.clips[index];
    final maxMs = clip.durationMs;
    final newOut = (value * maxMs).round().clamp(1, maxMs);
    setState(() {
      clip.sourceInMs = 0;
      clip.sourceOutMs = newOut;
    });
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String timeLabel(int ms) {
    final seconds = ms ~/ 1000;
    return '${(seconds ~/ 60).toString().padLeft(2, '0')}:${(seconds % 60).toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _preview?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final selected = selectedClipIndex != null &&
            selectedClipIndex! < videoTrack.clips.length
        ? videoTrack.clips[selectedClipIndex!]
        : null;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: midnight,
        titleSpacing: 16,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
              decoration: BoxDecoration(color: gold, borderRadius: BorderRadius.circular(8)),
              child: const Text('308', style: TextStyle(color: midnight, fontWeight: FontWeight.w900)),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('EMPIRE STUDIOS', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, letterSpacing: 1.1)),
                Text('PRO VIDEO EDITOR', style: TextStyle(fontSize: 9, color: gold, letterSpacing: 1.5)),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Project information',
            onPressed: () => showAboutDialog(
              context: context,
              applicationName: '308 Empire Studios',
              applicationVersion: '0.1.0 prototype',
              children: const [Text('A cross-platform video editor starter. Export rendering is not implemented yet.')],
            ),
            icon: const Icon(Icons.info_outline, color: silver),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            TextField(
              controller: TextEditingController(text: projectName)
                ..selection = TextSelection.collapsed(offset: projectName.length),
              onChanged: (v) => projectName = v,
              decoration: const InputDecoration(labelText: 'PROJECT NAME', prefixIcon: Icon(Icons.movie_creation_outlined)),
            ),
            const SizedBox(height: 14),
            _sectionTitle('PREVIEW MONITOR'),
            Container(
              width: double.infinity,
              constraints: const BoxConstraints(minHeight: 190, maxHeight: 300),
              decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(14), border: Border.all(color: const Color(0xFF35373D))),
              child: _preview != null && _preview!.value.isInitialized
                  ? AspectRatio(
                      aspectRatio: _preview!.value.aspectRatio,
                      child: VideoPlayer(_preview!),
                    )
                  : const Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.movie_outlined, size: 48, color: gold),
                          SizedBox(height: 8),
                          Text('308 EMPIRE STUDIOS', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 2)),
                          Text('Import a video to begin', style: TextStyle(color: silver, fontSize: 12)),
                        ],
                      ),
                    ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Text(_preview?.value.isInitialized == true ? timeLabel(_preview!.value.position.inMilliseconds) : '00:00',
                    style: const TextStyle(color: silver, fontFeatures: [])),
                const Spacer(),
                IconButton(
                  onPressed: _preview == null ? null : () async {
                    final c = _preview!;
                    if (c.value.isPlaying) {
                      await c.pause();
                    } else {
                      await c.play();
                    }
                    setState(() {});
                  },
                  icon: Icon(_preview?.value.isPlaying == true ? Icons.pause_circle : Icons.play_circle,
                      size: 38, color: gold),
                ),
                const Spacer(),
                Text(_preview?.value.isInitialized == true ? timeLabel(_preview!.value.duration.inMilliseconds) : '00:00',
                    style: const TextStyle(color: silver)),
              ],
            ),
            if (_preview != null && _preview!.value.isInitialized)
              VideoProgressIndicator(_preview!, allowScrubbing: true, colors: const VideoProgressColors(playedColor: gold, bufferedColor: silver, backgroundColor: Color(0xFF34363C))),
            const SizedBox(height: 18),
            _sectionTitle('MEDIA & TIMELINE'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.icon(onPressed: isImporting ? null : importVideo, icon: const Icon(Icons.video_library_outlined), label: const Text('Import video')),
                OutlinedButton.icon(onPressed: importAudio, icon: const Icon(Icons.audio_file_outlined), label: const Text('Add music')),
                OutlinedButton.icon(onPressed: splitSelectedClip, icon: const Icon(Icons.content_cut), label: const Text('Split clip')),
              ],
            ),
            const SizedBox(height: 12),
            _trackView(videoTrack, selected),
            _trackView(tracks[1], null),
            _trackView(audioTrack, null),
            if (selected != null) ...[
              const SizedBox(height: 12),
              _sectionTitle('TRIM SELECTED CLIP'),
              Text('${selected.name} · ${timeLabel(selected.visibleDurationMs)}', style: const TextStyle(color: silver)),
              Slider(
                value: (selected.sourceOutMs / selected.durationMs).clamp(0.01, 1.0),
                onChanged: trimSelectedClip,
                min: 0.01,
                max: 1,
                activeColor: gold,
              ),
              const Text('Prototype trim-out control. A full in/out range editor is planned.', style: TextStyle(color: silver, fontSize: 11)),
            ],
            const SizedBox(height: 18),
            _sectionTitle('EDITING TOOLS'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final tool in ['Select', 'Trim', 'Split', 'Effects', 'Text', 'Audio', 'Colour', 'Layers', 'Speed'])
                  ChoiceChip(
                    label: Text(tool),
                    selected: activeTool == tool,
                    selectedColor: gold.withOpacity(.22),
                    onSelected: (_) => setState(() => activeTool = tool),
                  ),
              ],
            ),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('EXPORT STUDIO', style: TextStyle(color: gold, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  SizedBox(height: 6),
                  Text('Native rendering integration is the next engineering milestone.', style: TextStyle(color: silver)),
                  SizedBox(height: 4),
                  Text('No video file is rendered by this starter yet.', style: TextStyle(color: Colors.orangeAccent, fontSize: 12)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(text, style: const TextStyle(color: gold, fontSize: 12, fontWeight: FontWeight.w800, letterSpacing: 1.3)),
      );

  Widget _trackView(TimelineTrack track, TimelineClip? selected) {
    final icon = switch (track.kind) {
      TrackKind.video => Icons.videocam_outlined,
      TrackKind.audio => Icons.graphic_eq,
      TrackKind.overlay => Icons.layers_outlined,
    };
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(icon, color: gold, size: 16),
            const SizedBox(width: 6),
            Text(track.name, style: const TextStyle(color: silver, fontSize: 10, fontWeight: FontWeight.bold)),
            const Spacer(),
            Text('${track.clips.length} clips', style: const TextStyle(color: silver, fontSize: 10)),
          ]),
          const SizedBox(height: 7),
          if (track.clips.isEmpty)
            const Text('Empty track', style: TextStyle(color: Color(0xFF777B84), fontSize: 11))
          else
            SizedBox(
              height: 43,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: track.clips.length,
                separatorBuilder: (_, __) => const SizedBox(width: 4),
                itemBuilder: (context, index) {
                  final clip = track.clips[index];
                  final isSelected = track.kind == TrackKind.video &&
                      selectedClipIndex == index;
                  return GestureDetector(
                    onTap: track.kind == TrackKind.video
                        ? () => setState(() {
                              selectedClipIndex = index;
                              playheadMs = clip.sourceInMs;
                            })
                        : null,
                    child: Container(
                      constraints: const BoxConstraints(minWidth: 105),
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        color: track.kind == TrackKind.audio
                            ? const Color(0xFF245A4C)
                            : isSelected
                                ? const Color(0xFF6B5730)
                                : const Color(0xFF454052),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: isSelected ? gold : Colors.transparent, width: 1.5),
                      ),
                      child: Center(
                        child: Text(clip.name, maxLines: 2, overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10, color: Colors.white)),
                      ),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
